#ifndef GAME_OVER_H
#define GAME_OVER_H

#include "game.h"

void render_game_over(size_t width, size_t height);

#endif
